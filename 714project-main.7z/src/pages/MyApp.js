import { Status, Wrapper } from "@googlemaps/react-wrapper";
import React, { useEffect, useRef } from "react";

const GoogleMap = ({ center }) => {
    const ref = useRef();
    useEffect(() => {
      new window.google.maps.Map(ref.current, {
        center,
        zoom: 16,
      });
    }, [center]);
    return <div ref={ref} id="map" style={{ height: "100vh" }} />;
  };


const render = (status) => {
  switch (status) {
    case Status.LOADING:
      return <div>Loading...</div>;
    case Status.FAILURE:
      return <div>Error</div>;
    default:
      return null;
  }
};

const MyApp = ({ coords }) => {
  const center = { lat: coords.latitude, lng: coords.longitude };
  return (
    <Wrapper apiKey={"AIzaSyAXf5iZ79WWzZ3gf17SVyM9b6i6vOS_QNk"} render={render}>
      <GoogleMap center={center}></GoogleMap>
    </Wrapper>
  );
};

MyApp.propTypes = {};

MyApp.defaultProps = {};

export default MyApp;